Français - Termes d'utilisations

Cette ressource a été créée par Benjamin SANCHEZ, à partir d'une ressource créée par Kb a.k.a Sebastien Gabriel, pour blogduwebdesign.com.

Vous pouvez utiliser et/ou modifier l'intégralité de cette ressource dans n'importe quel projet, qu'il soit commercial ou non sans aucune restriction.
Vous pouvez également utiliser cette ressource, sans restriction, dans le design de logiciel, templates web / thèmes destinés à la vente ou à la distribution. Aucun lien vers www.sebastiengabriel.com ou www.blogduwebdesign.com n'est demandé mais en parlé autour de vous sera grandement apprécié.

Il est interdit de vous attribuer la réalisation de cette ressource.
Il est interdit de revendre cette ressource telle quelle.
Il est interdit de proposer cette ressource en téléchargement direct sur n'importe quel site sans une permission préalable.

Si vous voulez partager cette ressources, prière de le faire en donnant un lien direct vers www.blogduwebdesign.com

Enjoy!

www.blogduwebdesign.com

English - Terms of use 

This resource was created by Benjamin SANCHEZ from a resources by Kb a.k.a Sebastien Gabriel, for sebastiengabriel.com and blogduwebdesign.com

You are free to use and/or modify this resource in any commercial or free project without any restriction.
You can use this resource, without restriction, un software design, web templates / theme intended for sale or distribution.
No backlinks to www.sebastiengabriel.com or www.blogduwebdesign.com is needed but spreading the word would be really appreciated.

You are not allowed to assign you the credit for this resource.
You are not allowed to sell this resource "as is".
You are not allowed to give this resource in direct download on any website without permission.

If you want to share this resource, please provide a direct link to www.blogduwebdesign.com

Enjoy!

www.blogduwebdesign.com

------------------------

This resource is under creative commons

------------------------ 
